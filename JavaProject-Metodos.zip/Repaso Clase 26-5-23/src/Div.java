import java.util.Scanner;

public class Div {

	public  void div() {
		// TODO Auto-generated method stub

		System.out.println("Bienvenido a la operacion de Division");
		System.out.print ("Por favor ingrese el valor 1: ");
		Scanner leer = new Scanner(System.in);
		int valor1 = leer.nextInt();
		System.out.print("Por favor ingrese el valor 2: ");
		int valor2 = leer.nextInt();
		int total = valor1 / valor2;
		System.out.println("La division corresponde a: "+total);
	}

}
