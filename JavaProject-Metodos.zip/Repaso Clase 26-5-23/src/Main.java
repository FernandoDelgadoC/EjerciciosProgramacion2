/* El programa deberá almacenar 2 dígitos ingresados por el usuario y realizar la operación indicada.
Deberá contar con un menú de ingreso que muestre el mensaje “Bienvenido desea realizar una operación matemática, 
digite uno para continuar o cualquier otra tecla para salir”
	Si el usuario digita uno mostrar un menú con el siguiente 	mensaje:
	“Gracias por continuar
	  Uno para suma.
	  Dos para resta.
	  Tres para multiplicación.
	  Cuatro para división”
	  
Crear un método para cada operación y hacer el llamado desde el programa principal.
 */

//Librerias
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	  System.out.print("Bienvenido, desea realizar una operacion matematicas?, por favor ingrese 1 para continuar o cualquier tecla para salir: ");
	  Scanner leer = new Scanner(System.in);
	  int entrada = 0;
	 //Comprobacion
	  boolean esNumeroValido=false;
	  while(!esNumeroValido) {
		  if(leer.hasNextInt()) {
			  entrada = leer.nextInt();
			  esNumeroValido = true;
		  }else {
			  System.out.println("No se ha ingresado un numero valido");
			  System.out.print("Por favor ingrese 1 para continuar o cualquier numero para salir: ");
			  leer.nextLine();
		  }
	  }
	  //Fin Comprobacion
	  //Si la entrada es 1 entonces se continua
	  if(entrada==1) {
		  System.out.println("Gracias por continuar");
		  System.out.println("1 para Suma");
		  System.out.println("2 para Resta");
		  System.out.println("3 para multiplicacion");
		  System.out.println("4 para division");
		  System.out.print("Por favor digite una opcion del menu: ");
		  int opcion = leer.nextInt();
		  //Inicio del switch case del menu
		  switch(opcion) {
		  	case 1:
		  		//Se crea un metodo Suma para llamar a ese metodo con el nombre laSuma
		  		Suma laSuma = new Suma();
		  		laSuma.suma();
		  		break;
		  	case 2:
		  		Resta laResta = new Resta();
		  		laResta.resta();
		  		break;
		  		
		  	case 3:
	
		  		Multi lamulti = new Multi();
		  		lamulti.multi();
		  		break;
		  	case 4:
		  		Div ladiv= new Div();
		  		ladiv.div();
		  		break;
		  		
		  	default:
		  		System.out.println("La opcion no esta en el menu");
		  		break;
		  }
		  
		 System.out.println("Gracias por usar la aplicacion");
	  }else {
		  System.out.println("Gracias por usar la aplicacion");
	  }
	}

}
